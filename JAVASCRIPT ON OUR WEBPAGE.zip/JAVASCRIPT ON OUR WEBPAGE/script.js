4+3;

if (4+3 ===7){
	alert("Your smart!");
}
console.log("Hello");